#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
: "${THEOS:?Set THEOS to your initialized Theos checkout}"
: "${LDID:?Set LDID to Procursus ldid}"
unset DEVELOPMENT_TEAM
export PATH="$(dirname "$LDID"):$PATH"
tar -xf libzip-0.11.2.tar.xz
mkdir -p libzip-build libzip-ios
RBX_SOURCE_ROOT="$PWD"
RBX_SDK="$(xcrun --sdk iphoneos --show-sdk-path)"
RBX_CC="$(xcrun --sdk iphoneos --find clang)"
cd libzip-build
CC="$RBX_CC" CFLAGS="-arch arm64 -isysroot $RBX_SDK -miphoneos-version-min=15.0 -Wno-error=implicit-function-declaration" LDFLAGS="-arch arm64 -isysroot $RBX_SDK -miphoneos-version-min=15.0" ../libzip-0.11.2/configure --host=aarch64-apple-darwin --disable-shared --enable-static --prefix="$RBX_SOURCE_ROOT/libzip-ios"
make -j4
make install
cd "$RBX_SOURCE_ROOT/AppSync"
patch -p1 < ../packaging.patch
cd appinst
for RBX_SCHEME in rootless ''; do
  make clean package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME="$RBX_SCHEME" ARCHS=arm64 TARGET=iphone:clang:16.5:15.0 appinst_LDFLAGS="$RBX_SOURCE_ROOT/libzip-ios/lib/libzip.a"
done
