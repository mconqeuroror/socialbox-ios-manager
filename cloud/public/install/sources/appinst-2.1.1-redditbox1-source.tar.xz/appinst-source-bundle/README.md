# RedditBox appinst dependency source bundle

appinst: upstream akemin-dayo/AppSync, commit 235aca6cddfbdc9fa87fcb5b2aec2df37ed6d65a (tag 116.0), appinst version 2.1.1.
Source: https://github.com/akemin-dayo/AppSync/tree/235aca6cddfbdc9fa87fcb5b2aec2df37ed6d65a
License: GPLv3; the complete upstream tree and license are in AppSync/.
This tree also contains corresponding source for the unchanged official AppSync Unified 116.0 binaries distributed by RedditBox.

libzip: official 0.11.2 source archive from https://libzip.org/download/libzip-0.11.2.tar.xz, statically linked as upstream appinst documents. License and copyright notices are inside that archive.

RedditBox packaging changes, 2026-09-09: Pre-Depends now requires firmware >= 15.0, matching the build deployment target; Debian revision is 2.1.1-redditbox1. No appinst Objective-C source changes. The exact packaging changes are in packaging.patch. arm64 is used for the iPhone 8/8 Plus/X target and both jailbreak filesystem layouts.

Build on macOS using Xcode, initialized Theos with the patched iOS 16.5 SDK, GNU Make, Python and Procursus ldid. Set THEOS and LDID, then run bash build.sh in a fresh extraction. No Apple Development Team is used. The release Mac used Xcode 26.6 (iPhoneOS 26.5 SDK for libzip; Theos patched 16.5 SDK for appinst). Both target iOS 15.0 or later. Build outputs are in AppSync/appinst/debs/.

Compilation, package paths, arm64 architecture, Mach-O load commands and ldid entitlements were checked on the Mac. Successful installation and runtime behavior still require testing on the iPhone. This is a RedditBox rebuild of upstream appinst, not an upstream binary release.
